# Personal Portfolio — Reference Design

This is a static HTML/CSS/JavaScript implementation of the approved portfolio visual reference.

## Files
- `index.html` — page structure and content
- `style.css` — visual design and responsive layout
- `script.js` — interactions and project carousel
- `assets/hero-photo.png` — local hero visual
- `assets/about-photo.png` — local about visual

## GitHub Pages
Upload the files to the root of your `Personal_Portfolio` repository and make sure `index.html` is in the repository root.

GitHub Pages will then serve the site as a static website.

## Before publishing
Replace these placeholders in `index.html`:
- `your-email@example.com`
- phone number
- LinkedIn `#`
- project `#` links
- resume link

The project names used here are based on the projects discussed during the portfolio planning. Edit any card that does not match your final GitHub project list.
