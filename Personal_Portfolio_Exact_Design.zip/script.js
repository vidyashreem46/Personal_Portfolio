const cursor = document.querySelector(".cursor-glow");
window.addEventListener("pointermove", e => {
  if(cursor){ cursor.style.left = e.clientX + "px"; cursor.style.top = e.clientY + "px"; }
});

const track = document.getElementById("projectTrack");
const prev = document.getElementById("prevProject");
const next = document.getElementById("nextProject");
const dots = [...document.querySelectorAll("#projectDots span")];

function moveProjects(direction){
  const card = track.querySelector(".project-card");
  const distance = card ? card.getBoundingClientRect().width + 15 : 250;
  track.scrollBy({left: direction * distance, behavior:"smooth"});
  const max = track.scrollWidth - track.clientWidth;
  const current = track.scrollLeft + direction * distance;
  const index = Math.max(0, Math.min(dots.length - 1, Math.round(current / Math.max(distance,1))));
  dots.forEach((d,i)=>d.classList.toggle("active", i===index));
}
prev.addEventListener("click", ()=>moveProjects(-1));
next.addEventListener("click", ()=>moveProjects(1));

document.querySelectorAll(".nav a").forEach(link=>{
  link.addEventListener("click",()=>{
    document.querySelectorAll(".nav a").forEach(a=>a.classList.remove("active"));
    link.classList.add("active");
  });
});

const reveal = new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add("visible");
      reveal.unobserve(entry.target);
    }
  });
},{threshold:.12});

document.querySelectorAll(".project-card,.skill-card,.cert-card,.time-item,.trait").forEach(el=>{
  el.classList.add("reveal");
  reveal.observe(el);
});

const style = document.createElement("style");
style.textContent = `
.reveal{opacity:0;transform:translateY(14px);transition:opacity .6s ease,transform .6s ease}
.reveal.visible{opacity:1;transform:none}
`;
document.head.appendChild(style);
